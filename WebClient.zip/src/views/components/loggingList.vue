<template>
  <div class="infinite-list-wrapper" style="overflow:auto">
    <ul
      v-infinite-scroll="load"
      class="list"
      infinite-scroll-disabled="disabled"
    >
      <li class="list-item">2022/03/15 08:15 登录成功</li>
      <li class="list-item">2022/03/16 11:21 登录成功</li>
      <li class="list-item">2022/03/17 21:20 登录成功</li>
      <li class="list-item">2022/03/18 12:21 登录成功</li>
    </ul>
    <p v-if="loading">loading</p>
    <p v-if="noMore">no more logs</p>
  </div>
</template>

<script>
export default {
  data () {
    return {
      count: 10,
      loading: false
    }
  },
  computed: {
    noMore () {
      return this.count >= 10
    },
    disabled () {
      return this.loading || this.noMore
    }
  },
  methods: {
    load () {
      this.loading = true
      setTimeout(() => {
        this.count += 2
        this.loading = false
      }, 2000)
    }
  }
}
</script>
