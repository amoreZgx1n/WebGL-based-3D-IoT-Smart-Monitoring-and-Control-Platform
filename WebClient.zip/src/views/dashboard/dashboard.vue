<template>
  <!--  <Comp/>-->
  <!--  <comp/>-->
  <el-main>
    <div id="myChart" style="width: auto;height: 400px"></div>
    <el-row>
      <el-col span="8">
        <el-card class="box-card" shadow="hover">
          <div slot="header" class="clearfix">
            <span>传感器昨日平均数据</span>
            <el-button style="float: right; padding: 3px 0" type="text"
              >管理</el-button
            >
          </div>
          <div class="text item">温湿度传感器: 24.2/44%</div>
          <div class="text item">水质传感器: 0.11/0.22</div>
          <div class="text item">光照传感器: 1201</div>
          <div class="text item">声音传感器: 13</div>
        </el-card>
      </el-col>
      <el-col span="8">
        <el-alert
          title="异常警告"
          type="warning"
          description="3/14 15:25 温度高于阈值"
          show-icon
        >
        </el-alert>
        <el-alert
          title="异常警告"
          type="warning"
          description="3/17 12:13 温度高于阈值"
          show-icon
        >
        </el-alert>
        <el-alert
          title="严重异常"
          type="error"
          description="3/21 11:24 湿度严重高于阈值"
          show-icon
        >
        </el-alert>
        <el-alert
          title="异常警告"
          type="warning"
          description="3/22 09:15 湿度低于阈值"
          show-icon
        >
        </el-alert>
      </el-col>
      <el-col span="8">
        <loggingList />
      </el-col>
    </el-row>
  </el-main>
</template>

<script>
import * as echarts from 'echarts'
import axios from 'axios'
import loggingList from '@/views/components/loggingList'

export default {
  name: 'DynamicLineChart',
  components: {
    loggingList
  },
  data () {
    return {
      // 实时数据数组
      urls: [],
      date: [],
      yieldData: [],
      // 折线图echarts初始化选项
      echartsOption: {
        legend: {
          data: []
        },
        xAxis: {
          name: '时间',
          nameTextStyle: {
            fontWeight: 600,
            fontSize: 18
          },
          type: 'category',
          boundaryGap: false,
          data: this.date // 绑定实时数据数组
        },
        yAxis: {
          name: '实时数据',
          nameTextStyle: {
            fontWeight: 600,
            fontSize: 18
          },
          type: 'value',
          scale: true,
          boundaryGap: ['15%', '15%'],
          axisLabel: {
            interval: 'auto',
            formatter: '{value}'
          }
        },
        tooltip: {
          trigger: 'axis'
        },
        series: []
      }
    }
  },
  mounted () {
    this.myChart = echarts.init(document.getElementById('myChart'), 'light') // 初始化echarts, theme为light
    const url = new URL('http://101.132.165.23:3000/get-sensors')
    axios.get(url).then(res => {
      const data = res.data.result.filter(row => row.bind_table)

      for (const row of data) {
        const url = new URL(`http://101.132.165.23:3000/get-table-latest`)
        url.searchParams.set('table', row.bind_table)
        this.urls.push(url)
      }

      Promise.all(this.urls.map(url => axios.get(url))).then(values => {
        this.echartsOption.legend.data = values.flatMap((value, i) =>
          Object.keys(value.data.result[0])
            .slice(6)
            .map(field => data[i].name + ':' + field)
        )
        this.echartsOption.series = this.echartsOption.legend.data.map(field => ({
          name: field,
          type: 'line',
          smooth: true,
          data: []
        }))
      })
    })
    this.myChart.setOption(this.echartsOption) // echarts设置初始化选项
    setInterval(this.addData, 1000) // 每三秒更新实时数据到折线图
  },
  methods: {
    // 获取当前时间
    getTime: (timestamp = 0) => {
      const t = timestamp ? new Date(timestamp * 1000) : new Date()
      const h = t.getHours()
      const i = t.getMinutes()
      const s = t.getSeconds()
      // 定义时间格式
      return (
        (h < 10 ? '0' + h : h) +
        ':' +
        (i < 10 ? '0' + i : i) +
        ':' +
        (s < 10 ? '0' + s : s)
      )
    },
    // 添加实时数据
    addData: function () {
      Promise.all(this.urls.map(url => axios.get(url))).then(values => {
        let index = 0
        for (const value of values) {
          const data = Object.values(value.data.result[0]).slice(6)
          for (const i of data) {
            this.echartsOption.series[index].data.push(i)
            index += 1
          }
        }

        this.date.push(this.getTime(Math.round(new Date().getTime() / 1000)))
        if (this.date.length > 30) {
          this.date.shift()
          this.echartsOption.series.forEach(x => x.data.shift())
        }
        this.echartsOption.xAxis.data = this.date
        this.myChart.setOption(this.echartsOption)
      })
    }
  }
}
</script>

<style scoped></style>

<style>
.text {
  font-size: 10px;
}

.item {
  margin-bottom: 18px;
}

.clearfix:before,
.clearfix:after {
  display: table;
  content: '';
}
.clearfix:after {
  clear: both;
}

.box-card {
  width: 360px;
}
.el-alert {
  width: 360px;
}
</style>
