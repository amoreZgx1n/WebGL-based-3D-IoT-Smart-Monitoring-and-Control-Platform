<template>
  <el-form ref="form" :model="sizeForm" label-width="80px">
    <el-form-item label="问题内容">
      <el-input v-model="sizeForm.name"></el-input>
    </el-form-item>
    <el-form-item label="提交地点">
      <el-select v-model="sizeForm.region" placeholder="请选择活动区域">
        <el-option label="实验室" value="shanghai"></el-option>
        <el-option label="5楼会议室" value="beijing"></el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="提交时间">
      <el-col :span="11">
        <el-date-picker
          v-model="sizeForm.date1"
          type="date"
          placeholder="选择日期"
          style="width: 100%;"
        ></el-date-picker>
      </el-col>
      <el-col class="line" :span="2">-</el-col>
      <el-col :span="11">
        <el-time-picker
          v-model="sizeForm.date2"
          placeholder="选择时间"
          style="width: 100%;"
        ></el-time-picker>
      </el-col>
    </el-form-item>
    <el-form-item label="问题性质">
      <el-checkbox-group v-model="sizeForm.type">
        <el-checkbox-button
          label="传感器物理故障"
          name="type"
        ></el-checkbox-button>
        <el-checkbox-button
          label="传感器数据异常"
          name="type"
        ></el-checkbox-button>
        <el-checkbox-button label="控制台异常" name="type"></el-checkbox-button>
        <el-checkbox-button label="3D模型异常" name="type"></el-checkbox-button>
        <el-checkbox-button label="其他问题" name="type"></el-checkbox-button>
      </el-checkbox-group>
    </el-form-item>
    <el-form-item label="用户权限">
      <el-radio-group v-model="sizeForm.resource" size="medium">
        <el-radio border label="管理员"></el-radio>
        <el-radio border label="普通用户"></el-radio>
      </el-radio-group>
    </el-form-item>
    <el-form-item size="large">
      <el-button type="primary" @click="onSubmit">立即上传</el-button>
      <el-button>取消</el-button>
    </el-form-item>
  </el-form>
</template>

<script>
export default {
  data () {
    return {
      sizeForm: {
        name: '',
        region: '',
        date1: '',
        date2: '',
        delivery: false,
        type: [],
        resource: '',
        desc: ''
      }
    }
  },
  methods: {
    onSubmit () {
      console.log('submit!')
    }
  }
}
</script>
