<template>
  <div>
    <canvas id="three"></canvas>
  </div>
</template>
<script>
import * as THREE from 'three'

export default {
  name: 'App3d',
  data () {
    return {}
  },
  mounted () {
    this.init()
  },
  methods: {
    init () {
      console.log('initialized')
      const scene = new THREE.Scene()

      // 创建一个基本透视摄像机 camera
      const camera = new THREE.PerspectiveCamera(
        75,
        window.innerWidth / window.innerHeight,
        0.1,
        1000
      )
      camera.position.z = 4

      // 找到canvas
      const canvas = document.querySelector('#three')

      // 创建一个抗锯齿渲染器并渲染到DOM
      const renderer = new THREE.WebGLRenderer({ canvas, antialias: true })

      // 配置渲染器清除颜色
      renderer.setClearColor('#000000')

      // 配置渲染器尺寸
      renderer.setSize(window.innerWidth, window.innerHeight)

      // 创建一个立方体网格
      const geometry = new THREE.BoxGeometry()
      const material = new THREE.MeshBasicMaterial({ color: '#433f81' })
      const cube = new THREE.Mesh(geometry, material)

      // 将立方体添加到场景中
      scene.add(cube)

      const render = () => {
        requestAnimationFrame(render)

        cube.rotation.x += 0.1
        cube.rotation.y += 0.01

        renderer.render(scene, camera)
      }

      render()
    }
  }
}
</script>

<style>
body {
  margin: 0;
}
canvas {
  width: 100%;
  height: 100%;
}
</style>
