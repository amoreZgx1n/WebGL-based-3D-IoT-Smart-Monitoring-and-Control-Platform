<template>
  <div class="app-container">
    <el-table
      v-loading="listLoading"
      :data="list"
      element-loading-text="Loading"
      border
      fit
      highlight-current-row
    >
      <el-table-column label="序号" align="center" width="95">
        <template slot-scope="scope">
          {{ scope.$index }}
        </template>
      </el-table-column>
      <el-table-column label="设备名" width="110" align="center">
        <template slot-scope="scope">
          {{ scope.row.name }}
        </template>
      </el-table-column>
      <el-table-column label="设备类型" width="110" align="center">
        <template slot-scope="scope">
          <span>{{ scope.row.type }}</span>
        </template>
      </el-table-column>
      <el-table-column label="最后更新" width="110" align="center">
        <template slot-scope="scope">
          {{ scope.row.last_updated }}
        </template>
      </el-table-column>
      <el-table-column label="功能码" width="110" align="center">
        <template slot-scope="scope">
          <span>{{ scope.row.func_code }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="数据字段"
        width="200"
        align="center"
        prop="created_at"
      >
        <template slot-scope="scope">
          <span>{{ scope.row.fields }}</span>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  filters: {
    statusFilter (status) {
      const statusMap = {
        published: 'success',
        draft: 'gray',
        deleted: 'danger'
      }
      return statusMap[status]
    }
  },
  data () {
    return {
      list: null,
      listLoading: true
    }
  },
  created () {
    this.fetchData()
  },
  methods: {
    fetchData () {
      this.listLoading = true
      axios.get(`http://101.132.165.23:3000/get-sensors`).then(res => {
        const data = res.data.result
        const urls = []
        for (const [index, row] of data.map((row, i) => [i, row])) {
          if (row.bind_table) {
            const url = new URL(`http://101.132.165.23:3000/get-table-latest`)
            url.searchParams.set('table', row.bind_table)
            urls.push([index, url])
          }
        }

        Promise.all(urls.map(([index, url]) => axios.get(url))).then(values => {
          for (const [index, value] of values.map((value, i) => [
            urls[i][0],
            value
          ])) {
            const lastUpdated = value.data.result[0].date
            const fields = Object.keys(value.data.result[0]).slice(6).join('; ')
            data[index].last_updated = lastUpdated
            data[index].fields = fields
          }
          this.list = data
          this.listLoading = false
        })
      })
    }
  }
}
</script>
