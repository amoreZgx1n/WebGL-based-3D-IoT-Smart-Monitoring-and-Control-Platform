<template>
  <div class="app-container">
    <el-table
      v-loading="listLoading"
      :data="list"
      element-loading-text="Loading"
      border
      fit
      highlight-current-row
    >
      <el-table-column label="id" width="95" align="center">
        <template slot-scope="scope">
          {{ scope.$index }}
        </template>
      </el-table-column>
      <el-table-column label="date" width="110" align="center">
        <template slot-scope="scope">
    {{ scope.row.date }}
        </template>
      </el-table-column>
      <el-table-column label="state" width="110" align="center">
        <template slot-scope="scope">
          <span>{{ scope.row.state }}</span>
        </template>
      </el-table-column>
      <el-table-column label="delay" width="110" align="center">
        <template slot-scope="scope">
          {{ scope.row.delay }}
        </template>
      </el-table-column>
      <el-table-column
        class-name="status-col"
        label="info"
        width="110"
        align="center"
      >
        <template slot-scope="scope">
          <el-tag :type="scope.row.info | statusFilter">{{
            scope.row.info
          }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="created_at" label="raw" width="200">
        <template slot-scope="scope">
          <span>{{ scope.row.raw }}</span>
        </template>
      </el-table-column>
      <el-table-column
        align="center"
        prop="created_at"
        label="humidity"
        width="200"
      >
        <template slot-scope="scope">
          <span>{{ scope.row.humidity }}</span>
        </template>
      </el-table-column>
      <el-table-column
        align="center"
        prop="created_at"
        label="temperature"
        width="200"
      >
        <template slot-scope="scope">
          <span>{{ scope.row.temperature }}</span>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  filters: {
    statusFilter (status) {
      const statusMap = {
        published: 'success',
        draft: 'gray',
        deleted: 'danger'
      }
      return statusMap[status]
    }
  },
  data () {
    return {
      list: null,
      listLoading: true
    }
  },
  created () {
    this.fetchData()
  },
  methods: {
    fetchData () {
      this.listLoading = true
      const url = new URL('http://101.132.165.23:3000/get-table')
      const tableName = 'lora-p2p'
      const limit = 100
      url.searchParams.set('table', tableName)
      url.searchParams.set('limit', limit)
      axios.get(url).then(res => {
        this.list = res.data.result
        this.listLoading = false
      })
    }
  }
}
</script>
