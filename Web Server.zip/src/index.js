const express = require('express')
const mysql = require('mysql')
const bodyParser = require('body-parser')

const app = express()

const port = process.env.PORT ?? 3000

const DATABASE = {
  host: 'snowflyt-out.mysql.rds.aliyuncs.com',
  port: 3306,
  user: 'root',
  password: 'Jiangzemin1926',
  database: 'sensors'
}
const DATABASE2 = {
  host: 'snowflyt-out.mysql.rds.aliyuncs.com',
  port: 3306,
  user: 'root',
  password: 'Jiangzemin1926',
  database: 'actuators'
}

// get current date
const getCurrentDate = () => {
  const date = new Date()
  const year = date.getFullYear()
  const month =
    date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1
  const day = date.getDate() < 10 ? '0' + date.getDate() : date.getDate()
  const hour = date.getHours() < 10 ? '0' + date.getHours() : date.getHours()
  const minute = date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes()
  const second = date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds()
  return `${year}-${month}-${day} ${hour}:${minute}:${second}`
}
// print log
const log = (message, messageType = 'INFO') => {
  const date = getCurrentDate()
  console.log(`${date} [${messageType}] ${message}`)
}

app.use(bodyParser.urlencoded({ extended: false }))

// 解决跨域请求
app.all('*', (req, res, next) => {
  // 允许的来源
  res.header('Access-Control-Allow-Origin', '*')
  // 允许的头部信息，如果自定义请求头，需要添加以下信息，允许列表可以根据需求添加
  res.header(
    'Access-Control-Allow-Headers',
    'application/json',
    'Content-Type, Content-Length, Authorization, Accept, X-Requested-With, yourHeaderField'
  )
  // 允许的请求类型
  res.header('Access-Control-Allow-Methods', '*')
  res.header('X-Powered-By', ' 3.2.1')
  next()
})

// 直接处理前端传来的SQL语句
// 注：这很容易造成安全性问题，建议仅在试验时使用
// ?sql=...
app.get('/executeSQL', (req, res) => {
  const sql = req.query.sql

  connection = mysql.createConnection(DATABASE)
  connection.connect(err => {
    if (err) {
      log('database connection failed', 'ERROR')
      throw err
    }
    log('database connected successful')

    log('executing SQL: ' + sql)
    connection.query(sql, (err, result) => {
      if (err) {
        log('database query failed', 'ERROR')
        throw err
      } else {
        log('database queried successful')
        connection.end()
        res.send(JSON.stringify({ result, fields }))
      }
    })
  })
})

// 返回所有执行器信息
app.get('/get-actuators', (req, res) => {
  const sql = 'SELECT * FROM `actuators`;'

  connection = mysql.createConnection(DATABASE2)
  connection.connect()
  log('database connected')

  connection.query(sql, (err, result, fields) => {
    if (err) {
      // 失败，执行异常处理
      log(err, 'ERROR')
    } else {
      // 成功，返回请求信息
      log(result)
      res.send(JSON.stringify({ result, fields }))
    }
  })

  connection.end()
})

// 返回执行器3D界面信息
app.get('/get-actuators-3d', (req, res) => {
  const sql = 'SELECT * FROM `actuators-3d`;'

  connection = mysql.createConnection(DATABASE2)
  connection.connect()
  log('database connected')

  connection.query(sql, (err, result, fields) => {
    if (err) {
      // 失败，执行异常处理
      log(err, 'ERROR')
    } else {
      // 成功，返回请求信息
      log(result)
      res.send(JSON.stringify({ result, fields }))
    }
  })

  connection.end()
})

// 更新执行器3d界面坐标
app.get('/update-actuator-position-3d', (req, res) => {
  const room = req.query.room
  const name = req.query.name
  const x = req.query.x
  const y = req.query.y
  const z = req.query.z
  let sql = 'UPDATE `actuators-3d` '
  if (x !== undefined) {
    sql += `SET \`x\` = ${x}`
  }
  if (y !== undefined) {
    sql += `, \`y\` = ${y}`
  }
  if (z !== undefined) {
    sql += `, \`z\` = ${z}`
  }
  sql += ` WHERE \`name\` = "${name}"
            AND \`bind_room\` = "${room}";`
  
  console.log(sql)

  connection = mysql.createConnection(DATABASE2)
  connection.connect()
  log('database connected')

  connection.query(sql, (err, result, fields) => {
    if (err) {
      // 失败，执行异常处理
      log(err, 'ERROR')
    } else {
      // 成功，返回请求信息
      log(result)
      res.send(JSON.stringify({ result, fields }))
    }
  })

  connection.end()
})

// 返回所有传感器信息
app.get('/get-sensors', (req, res) => {
  const sql = 'SELECT * FROM `sensors`;'

  connection = mysql.createConnection(DATABASE)
  connection.connect()
  log('database connected')

  connection.query(sql, (err, result, fields) => {
    if (err) {
      // 失败，执行异常处理
      log(err, 'ERROR')
    } else {
      // 成功，返回请求信息
      log(result)
      res.send(JSON.stringify({ result, fields }))
    }
  })

  connection.end()
})

// 返回传感器3D界面信息
app.get('/get-sensors-3d', (req, res) => {
  const sql = 'SELECT * FROM `sensors-3d`;'

  connection = mysql.createConnection(DATABASE)
  connection.connect()
  log('database connected')

  connection.query(sql, (err, result, fields) => {
    if (err) {
      // 失败，执行异常处理
      log(err, 'ERROR')
    } else {
      // 成功，返回请求信息
      log(result)
      res.send(JSON.stringify({ result, fields }))
    }
  })

  connection.end()
})

// 更新传感器3d界面坐标
app.get('/update-sensor-position-3d', (req, res) => {
  const room = req.query.room
  const name = req.query.name
  const x = req.query.x
  const y = req.query.y
  const z = req.query.z
  let sql = 'UPDATE `sensors-3d` '
  if (x !== undefined) {
    sql += `SET x = ${x}`
  }
  if (y !== undefined) {
    sql += `, y = ${y}`
  }
  if (z !== undefined) {
    sql += `, z = ${z}`
  }
  sql += ` WHERE name = "${name}"
            AND bind_room = "${room}";`

  connection = mysql.createConnection(DATABASE)
  connection.connect()
  log('database connected')

  connection.query(sql, (err, result, fields) => {
    if (err) {
      // 失败，执行异常处理
      log(err, 'ERROR')
    } else {
      // 成功，返回请求信息
      log(result)
      res.send(JSON.stringify({ result, fields }))
    }
  })

  connection.end()
})

// 返回某表所有信息
// ?table=...&limit=...
app.get('/get-table', (req, res) => {
  const tableName = req.query.table
  const limit = req.query.limit
  let sql = 'SELECT * FROM `' + tableName + '`'
  if (limit !== undefined) {
    sql += ' LIMIT ' + limit
  }

  connection = mysql.createConnection(DATABASE)
  connection.connect()
  log('database connected')

  connection.query(sql, (err, result, fields) => {
    if (err) {
      // 失败，执行异常处理
      log(err, 'ERROR')
    } else {
      // 成功，返回请求信息
      log(result)
      res.send(JSON.stringify({ result, fields }))
    }
  })

  connection.end()
})

// 返回某表的最后一行数据
// ?table=...
app.get('/get-table-latest', (req, res) => {
  const tableName = req.query.table
  const sql = 'SELECT * FROM `' + tableName + '` ORDER BY `id` DESC LIMIT 1;'

  connection = mysql.createConnection(DATABASE)
  connection.connect()
  log('database connected')

  connection.query(sql, (err, result, fields) => {
    if (err) {
      // 失败，执行异常处理
      log(err, 'ERROR')
    } else {
      // 成功，返回请求信息
      // log(result)
      res.send(JSON.stringify({ result, fields }))
    }
  })

  connection.end()
})

app.listen(port, () =>
  console.log(
    `server started on port ${port}\n` + 'press Ctrl-C to terminate...'
  )
)
